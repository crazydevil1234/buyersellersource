'use strict';


/**
 * Expose the `stormpath` library.
 *
 * @property stormpath
 */
module.exports = require('./lib/stormpath');
